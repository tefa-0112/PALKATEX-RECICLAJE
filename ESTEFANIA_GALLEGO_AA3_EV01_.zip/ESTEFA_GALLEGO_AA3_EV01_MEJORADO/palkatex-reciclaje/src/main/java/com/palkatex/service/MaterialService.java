package com.palkatex.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.palkatex.model.Material;
import com.palkatex.repository.MaterialRepository;

@Service
public class MaterialService {

    private final MaterialRepository repo;

    public MaterialService(MaterialRepository repo) {
        this.repo = repo;
    }

    public List<Material> listar() {
        return repo.findAll();
    }

    public Material guardar(Material m) {
        return repo.save(m);
    }

    public void eliminar(int id) {
        repo.deleteById(id);
    }
}
