package com.palkatex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PalkatexApplication {
    public static void main(String[] args) {
        SpringApplication.run(PalkatexApplication.class, args);
    }
}
