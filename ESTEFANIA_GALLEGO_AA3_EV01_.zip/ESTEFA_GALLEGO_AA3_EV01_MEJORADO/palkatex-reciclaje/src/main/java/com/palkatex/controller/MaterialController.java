package com.palkatex.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import com.palkatex.model.Material;
import com.palkatex.service.MaterialService;

@RestController
@RequestMapping("/materiales")
public class MaterialController {

    private final MaterialService service;

    public MaterialController(MaterialService service) {
        this.service = service;
    }

    @GetMapping
    public List<Material> listar() {
        return service.listar();
    }

    @PostMapping
    public Material guardar(@RequestBody Material m) {
        return service.guardar(m);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable int id) {
        service.eliminar(id);
    }
}
