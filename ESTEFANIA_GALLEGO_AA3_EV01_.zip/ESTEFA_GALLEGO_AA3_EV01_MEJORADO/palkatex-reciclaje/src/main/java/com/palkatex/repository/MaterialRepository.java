package com.palkatex.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.palkatex.model.Material;

/**
 * Repositorio para acceso a datos
 */
public interface MaterialRepository extends JpaRepository<Material, Integer> {
}
